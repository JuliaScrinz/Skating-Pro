const cadastroForm = document.getElementById('cadastroForm');
cadastroForm.addEventListener('submit', function(event) {
  event.preventDefault();
  const nomeEscola = document.getElementById('nomeEscola').value;
  const nomeSecretaria = document.getElementById('nomeSecretaria').value;
  const email = document.getElementById('email').value;
  const senha = document.getElementById('password').value;

  fetch('http://localhost:2008/cadastro', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ nomeEscola, nomeSecretaria, email, senha})
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert(data.message);
      window.location.href = 'loginSecretaria.html';
    } else {
      alert(data.message);
    }
  });
});