create database SkatingPro;

use SkatingPro;

create table usuarioProfessores (
id int auto_increment primary key,
email varchar(255) not null,
senha varchar(255) not null
);

insert into usuarioProfessores (email, senha)
values ("juliascrinz", "pantufa")