create database SkatingPro;

use SkatingPro;

create table usuarioProfessores (
id int auto_increment primary key,
email varchar(255) not null,
senha varchar(255) not null
);
create table secretaria (
	id int auto_increment primary key,
    nomeEscola varchar(255) not null,
    nomeSecretaria varchar(255) not null,
	email varchar(255) not null,
	senha varchar(255) not null
);